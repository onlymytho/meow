
// getJSON
var getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    // xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
    // xhr.setRequestHeader('"Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE')
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status == 200) {
        callback(null, xhr.response);
      } else {
        callback(status);
      }
    };
    xhr.send();
};

// numberWithCommas
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}



// giphy
var offset = Math.floor(Math.random() * 500)
var giphy_search = ['cat']
var search_result = []
var called_count = 0
var giphy_callback = function(err, giphy_data) {
  if (err != null) {
    console.log('Something went wrong: ' + err);
  }
  else {
     for (i=0; i<giphy_data.data.length; i++) {
         var image_div = document.createElement( 'div' );
         image_div.className = 'image'
         var img = document.createElement( 'img' );
         image_div.appendChild( img );
         img.className = 'imgs'
         img.id = search_result.length
         img.src = giphy_data.data[i].images.downsized_large.url
         img.addEventListener('click', show_viewer, false);
         search_result.push(giphy_data.data[i].images.original.url)

         document.getElementsByClassName('images')[0].appendChild(image_div);
     }
 offset = offset + 9
  }
};
function call_giphy() {
    getJSON('https://api.giphy.com/v1/gifs/search?q='+giphy_search[0]+'&api_key=dc6zaTOxFJmzC&limit=9&offset='+offset, giphy_callback);
    called_count = called_count + 1
}



// viewer
var current_viewer_image = 0;

function ready_to_call_check() {
    if (9 * called_count - current_viewer_image  <  3) {
        call_giphy()
    }
}
function show_viewer(e) {
    document.getElementById('viewer').classList.add('on');
    document.getElementById('viewer_image').src = search_result[e.target.id]
    current_viewer_image = e.target.id
    ready_to_call_check()
};
function close_viewer() {
    document.getElementById('viewer').classList.remove('on');
}
function next_image() {
    var next_image = search_result[parseInt(current_viewer_image)+1]
    if ( !!next_image ) {
        document.getElementById('viewer_image').src = next_image
        current_viewer_image = parseInt(current_viewer_image) + 1
        ready_to_call_check()
    } else {
        call_giphy()
        document.getElementById('viewer_image').src = next_image
        current_viewer_image = parseInt(current_viewer_image) + 1
        ready_to_call_check()
    }
}
function prev_image() {
    var prev_image = search_result[parseInt(current_viewer_image)-1]
    if ( !!prev_image ) {
        document.getElementById('viewer_image').src = prev_image
        current_viewer_image = parseInt(current_viewer_image) - 1
    }
}



//  MAIN
call_giphy()
document.getElementById('more_meows').onclick = call_giphy;
document.getElementById('bg_layer').onclick = close_viewer;
document.getElementById('prev_button').onclick = prev_image;
document.getElementById('next_button').onclick = next_image;
